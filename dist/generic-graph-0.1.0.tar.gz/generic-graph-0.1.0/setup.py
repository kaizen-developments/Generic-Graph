from setuptools import setup, find_packages

setup(
    name='generic-graph',
    version='0.1.0',
    url='https://github.com/kaizendevelopments/generic-graph',
    author='Author Name',
    author_email='author@gmail.com',
    description='Description of my package',
    packages=find_packages(),    
    install_requires=[],
)